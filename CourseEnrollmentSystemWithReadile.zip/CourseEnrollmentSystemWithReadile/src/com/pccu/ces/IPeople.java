package com.pccu.ces;

public interface IPeople {
	int		getId ();
	void 	setId (int id);
	String 	getName ();
	void 	setName (String name);
	String 	getSex ();
	void 	setSex (String sex);
}
