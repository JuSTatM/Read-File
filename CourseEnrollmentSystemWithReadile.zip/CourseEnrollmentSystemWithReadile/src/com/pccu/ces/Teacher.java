package com.pccu.ces;

public class Teacher implements IPeople {
	int    	mId ;
	String 	mName = "";
	String 	mSex  = "";
	
	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void setName(String name) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public String getSex() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void setSex(String sex) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public int getId() {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public void setId(int id) {
		// TODO Auto-generated method stub
	}
	

}
